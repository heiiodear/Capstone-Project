const { MongoClient } = require("mongodb");
const axios = require("axios");

// MongoDB connection
const uri = "mongodb+srv://yanisa:Juliajokt1260.@capstoneproject.tekjtkq.mongodb.net/";
const client = new MongoClient(uri);

// Discord webhook
const webhookURL = "https://discord.com/api/webhooks/1369211314521505822/HcpwKo-INmzrvajVZkLcpd2oHTHNqxPLy-xK4oR4IWuhaV1QQD80ci23rD2sQCm7fiVb";

async function checkAndAlert() {
  try {
    await client.connect();
    const db = client.db("Capstone");
    const collection = db.collection("fall");

    const fallEvent = await collection.findOne({}, { sort: { _id: -1 } });

    if (fallEvent) {
      const videoURL = fallEvent.video_url;
      const imageURL = fallEvent.image_url;

      // ส่งแจ้งเตือนไป Discord
      await axios.post(webhookURL, {
        content: `🚨 พบเหตุการณ์ล้ม!\n🖼️ รูปภาพ: ${imageURL}\n🎥 คลิป: ${videoURL}`
      });

      console.log("✅ แจ้งเตือนสำเร็จ:", videoURL);

      // อัปเดตสถานะเพื่อป้องกันการแจ้งซ้ำ
      await collection.updateOne({ _id: fallEvent._id }, { $set: { status: "notified" } });
    } else {
      console.log("⏳ ยังไม่มีคลิปใหม่");
    }

  } catch (error) {
    console.error("❌ เกิดข้อผิดพลาด:", error);
  } finally {
    await client.close();
  }
}

checkAndAlert();